# Changelog

## 1.1

* Simplified network admin screens
* Added Behat tests - see [docs/behat-tests.md](docs/behat-tests.md)
* Added a fix to ensure pushed posts aren't put live before term sync takes place
* Line height tweak on edit job page
* Cleanup plugin helper class and usage
* Internationalisation

## 1.0

* Initial plugin - see readme